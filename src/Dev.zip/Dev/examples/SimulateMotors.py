import os
import sys
import glob

# Point Python directly to your Dev folder so it can find 'motor_lib'
sys.path.append(r"C:\D_Drive\Technical\MyPapers\CoggingVsLeakage\ModuleLibr\Dev")

from motor_lib.MotorControler.simulate import MotorFEAEngine

def run_test_simulation():
    print("==================================================")
    print("=== TEST MODE: FEA SIMULATION ===")
    print("==================================================")
    
    base_dir = os.path.join(os.getcwd(), "Rib_Test_Study")
    design_folders = sorted(glob.glob(os.path.join(base_dir, "Design_tr_*mm")))
    
    if not design_folders:
        print("No design folders found. Run the Test Geometry Builder first!")
        return

    for folder in design_folders:
        tr_val = os.path.basename(folder).replace("Design_tr_", "").replace("mm", "")
        print(f"\n{'='*50}\nTESTING: Rib Thickness = {tr_val} mm\n{'='*50}")
        
        fine_file = os.path.join(folder, f"Motor_tr_{tr_val}mm_Fine.fem")
        coarse_file = os.path.join(folder, f"Motor_tr_{tr_val}mm_Coarse.fem")

        # =========================================================
        # TEST A: COGGING (Very short sweep, DO NOT delete files)
        # =========================================================
        print("\n  >>> STAGE 1: Test Cogging (10 degrees, 11 steps)")
        motor_fine = MotorFEAEngine(
            filename=fine_file, base_folder=folder, p=8, q=48, Np=2,
            initial_rotor_pos=3.75, IP=90.0, band_name="AGap"
        )
        
        motor_fine.run_transient(
            I_rms=0.0, gamma_elec_deg=0.0,
            theta_start_elec=0.0, theta_end_elec=10.0, num_steps=11,       
            Ns_rpm=7000,
            delete_files=False
            # Removed name_extension entirely!
        )

        # =========================================================
        # TEST B: MTPA (Only 2 currents, coarse search, DO NOT delete files)
        # =========================================================
        print("\n  >>> STAGE 2: Test MTPA (2 currents)")
        motor_coarse = MotorFEAEngine(
            filename=coarse_file, base_folder=folder, p=8, q=48, Np=2,
            initial_rotor_pos=3.75, IP=90.0, band_name="AGap"
        )
        
        motor_coarse.run_mtpa(
            I_rms_list=[20.0, 42.7], 
            theta_start_elec=0.0, theta_end_elec=60.0, num_steps=7,      
            Ns_rpm=7000,
            delete_files=False, 
            coarse_step_deg=45.0, 
            run_fine_search=True,
            fine_window_deg=20.0, 
            fine_step_deg=5.0
            # Removed name_extension entirely!
        )

    print("\n>>> Test Suite Complete. Open the folders to inspect the .ans files!")

if __name__ == "__main__":
    run_test_simulation()